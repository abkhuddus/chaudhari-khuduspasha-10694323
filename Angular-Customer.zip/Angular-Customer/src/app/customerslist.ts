export class Customer {
id:number;
name:string;
age:string;
adress:string;
accountType:string    
}
