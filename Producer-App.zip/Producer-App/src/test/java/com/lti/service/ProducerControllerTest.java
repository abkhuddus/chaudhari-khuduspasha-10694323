package com.lti.service;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lti.controller.ProducerController;
import com.lti.model.Customer;

@RunWith(SpringRunner.class)
@WebMvcTest(value = ProducerController.class)
public class ProducerControllerTest {

	 @Autowired
	    private MockMvc mockMvc;

	    @MockBean
	    private CustomerService customerService;

	    @Test
	    public void testsaveCustomer() throws Exception{
	    	String URI="/api/customer";
	    	Customer c=new Customer();
			c.setId(121);
			c.setName("Test Customer");
			c.setAccountType("Saving Test");
			c.setAdress("Test Address");
			c.setAge("156");
			 String jsonInput = this.converttoJson(c);
			 Mockito.when(customerService.SaveCustomerTest(Mockito.any(Customer.class))).thenReturn(c);
			 MvcResult mvcResult = this.mockMvc.perform(MockMvcRequestBuilders.post(URI).accept(MediaType.APPLICATION_JSON).content(jsonInput).contentType(MediaType.APPLICATION_JSON))
			            .andReturn();
			 MockHttpServletResponse mockresponse=mvcResult.getResponse();
			 String jsonOutput = mockresponse.getContentAsString();
			    assertThat(jsonInput).isEqualTo(jsonOutput);
			    Assert.assertEquals(HttpStatus.OK.value(), mockresponse.getStatus());
	    }
	    
	    
	    private String converttoJson(Object ticket) throws JsonProcessingException {
	        ObjectMapper objectMapper = new ObjectMapper();
	        return objectMapper.writeValueAsString(ticket);
	    }
	
	
}
