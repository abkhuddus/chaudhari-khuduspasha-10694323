package com.lti.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.dao.CustomerRepository;
import com.lti.dto.CustomerDto;
import com.lti.exception.CustomerNotFoundException;
import com.lti.model.Customer;

@Service
public class CustomerServiceImpl implements CustomerService {
	static final Logger logger = Logger.getLogger(CustomerServiceImpl.class);

	
	@Autowired
	private CustomerRepository repo;
	
		
	
	@Override
	@Transactional
	public Customer save(CustomerDto dto)throws CustomerNotFoundException {
		
		try {
			logger.info("Entered into save");
			Customer c=new Customer();
			  c.setAccountType(dto.getAccountType());
			  c.setAdress(dto.getAdress());
			  c.setAge(dto.getAge());
			  c.setName(dto.getName());
			   Customer savedCustomer=repo.save(c);
				 if(savedCustomer!=null) {
					 return savedCustomer;
				 }else
					 throw new CustomerNotFoundException("Customer Not Saved");
		} catch (Exception e) {
			logger.error("Exception occure while saving Product");
			e.printStackTrace();
		}
		return null;
	}
		
	
	@Override
	public CustomerDto getByid(Integer id) {
		
		try {
			 Customer c=repo.findOne(id);
			 if(c==null)
		           throw new CustomerNotFoundException("Customer Not Found");
			 else {
				 
				 CustomerDto dto=new CustomerDto();
				 dto.setId(c.getId());
				 dto.setAccountType(c.getAccountType());
				 dto.setAdress(c.getAdress());
				 dto.setName(c.getName());
				 dto.setAge(c.getAge());
				 return dto;
			 }

		}  catch (Exception e) {
			  logger.error("Exception occure while geting Customer");	
				}
				return null;
			}
	
	
	
	
	

	@Override
	@Transactional(readOnly=true)
	public List<Customer> getAll() {
		logger.info("Entered getAllProduct");
      
        try {
        	  List<Customer> customerlist=repo.findAll();
        	  if(customerlist!=null) {
        		  return customerlist;  
        	  }
        	  else {
        		  throw new CustomerNotFoundException("Customer Not Found");
        	  }
			
		} catch (Exception e) {
     	   logger.error("error occures while geting customers list");

		}
        return null;
	}

	@Override
	public boolean deleteById(Integer id) {
		
		try {
			Customer c=repo.findOne(id);
			if(c==null) {
				throw new CustomerNotFoundException("Customer Not Found");
			}else {
					repo.delete(c);
					return true;	
			}
		} catch (Exception e) {
			logger.error("Exception occure while Deleteing Customer");	    
		}
		
		return false;
	}

	
	@Override
	public Customer update(Integer id,Customer customer) {
		try {
			if(customer!=null) {
				Customer c=repo.findOne(customer.getId());
				   if(c==null) {
					   throw new CustomerNotFoundException("Customer Not Found");
				   }
				   else {
					     c.setName(customer.getName());
						 c.setAge(customer.getAge());
						 c.setAdress(customer.getAdress());
						 c.setAccountType(customer.getAccountType());
				        return repo.save(customer);
				 }
			}
		} catch (Exception e) {
			logger.error("Exception occure while Updating Customer");	    
		}
		return null;

	}


	@Override
	public Customer SaveCustomerTest(Customer c) {
		return repo.save(c);
	}


	@Override
	public Customer getsByidTest(Integer id) {
		return repo.findOne(id);
	}


	@Override
	public List<Customer> getAllForTest() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}
}
