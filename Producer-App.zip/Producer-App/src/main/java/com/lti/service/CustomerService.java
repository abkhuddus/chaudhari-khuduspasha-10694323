package com.lti.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lti.dto.CustomerDto;
import com.lti.exception.CustomerNotFoundException;
import com.lti.model.Customer;
@Service
public interface CustomerService {

	
	public Customer save(CustomerDto customer) throws CustomerNotFoundException;
	
	public CustomerDto getByid(Integer id) throws CustomerNotFoundException;
	
	public List<Customer> getAll() throws CustomerNotFoundException;
	
	public boolean deleteById(Integer id) throws CustomerNotFoundException;
	
	public Customer update(Integer id,Customer customer) throws CustomerNotFoundException; 
	
	
	public Customer SaveCustomerTest(Customer c);
	
	public Customer getsByidTest(Integer id);
	
	public List<Customer>getAllForTest();
	
	
}
