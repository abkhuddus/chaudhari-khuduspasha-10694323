package com.lti.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lti.dto.CustomerDto;
import com.lti.exception.CustomerNotFoundException;
import com.lti.model.Customer;
import com.lti.service.CustomerService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@CrossOrigin(origins = "*")
@RequestMapping("/api")
@RestController
public class ProducerController {
		
	@Autowired
	private CustomerService service;
	
	
	
	@RequestMapping(value = "/customer", method = RequestMethod.POST)
	public ResponseEntity<?> save(@RequestBody CustomerDto customer) throws CustomerNotFoundException {
		   Customer c=service.save(customer);
		   if(c==null) {
				  return new ResponseEntity<String>("Customer Not Saved",HttpStatus.FAILED_DEPENDENCY); 
		   }
		  return new ResponseEntity<Customer>(c,HttpStatus.CREATED); 
	}
	
   
	
	@RequestMapping(value = "/customer", method = RequestMethod.GET)
	public ResponseEntity<?>  getCustomerdetails() throws CustomerNotFoundException {		
		 List<Customer> customerList= service.getAll();
		 if(!customerList.isEmpty()) {
				return new ResponseEntity<List<Customer>>(customerList,HttpStatus.OK);
			}else
				 throw new CustomerNotFoundException("Customers  Not Found In DataBase");
						
		}
	
	
	@RequestMapping(value = "/customer/{id}", method = RequestMethod.GET)
	public ResponseEntity<?> getCustomerdetailbyId(@PathVariable(value = "id") Integer id) throws CustomerNotFoundException {		
			 CustomerDto c=	 service.getByid(id);
			 if(c!=null) {
					return new ResponseEntity<CustomerDto>(c,HttpStatus.OK);
			 }else {
				 
				 throw new CustomerNotFoundException("Customers  Not Found In DataBase"); 
			 }
	}
	
   
	@RequestMapping(value = "/customer/{id}", method = RequestMethod.PUT)
	public ResponseEntity<?> updateEmployee(@PathVariable(value = "id") Integer id,
		 @RequestBody Customer customer) throws CustomerNotFoundException {
		
		Customer c= service.update(id, customer);
		 if(c!=null) {
				return new ResponseEntity<Customer>(c,HttpStatus.OK);
		 }
		 else {
			 throw new CustomerNotFoundException("Customers  Not Updated");  
		 }
	}
	
	
	@RequestMapping(value = "/getcustomer", method = RequestMethod.GET)
	@HystrixCommand(fallbackMethod = "getDataFallBack")
	public List<Customer>  getCustomer() throws CustomerNotFoundException {		
		 List<Customer> customerList= service.getAll();
	
		 if(customerList==null) {
			  new RuntimeException();
		 }
		 return customerList;	
	}
	

	@RequestMapping(value = "/customer/{id}", method = RequestMethod.DELETE)
	public Map<String, Boolean> deleteCustomerById(@PathVariable(value = "id") Integer id) throws CustomerNotFoundException {
		 Boolean tr=service.deleteById(id);
		 Map<String, Boolean> response = new HashMap<>();
			response.put("deleted", tr);
			return response;
	}
	
	
	public List<Customer> getDataFallBack() {
		Customer c = new Customer();
		c.setName("demo name");
		c.setAge("21");
		List<Customer> customerlist = new ArrayList<Customer>();
		customerlist.add(c);
		return customerlist; 
	}

}
